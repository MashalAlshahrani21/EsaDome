(function () {
  "use strict";

  const AI = [["chatgpt.com", "ChatGPT"], ["chat.openai.com", "ChatGPT"], ["claude.ai", "Claude"], ["gemini.google.com", "Gemini"], ["perplexity.ai", "Perplexity"], ["copilot.microsoft.com", "Microsoft Copilot"], ["poe.com", "Poe"], ["quillbot.com", "QuillBot"], ["grammarly.com", "Grammarly"], ["you.com", "You.com"], ["chat.deepseek.com", "DeepSeek"], ["grok.com", "Grok"], ["meta.ai", "Meta AI"]];
  const SCHOOL = ["docs.google.com", "classroom.google.com", "instructure.com", "schoology.com", "office.com", "word.office.com"];
  const host = (url) => { try { return new URL(url).hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; } };
  const match = (h, d) => h === d || h.endsWith(`.${d}`);
  const aiFor = (url) => { const h = host(url); const found = AI.find(([d]) => match(h, d)); return found && { domain: h, aiTool: found[1] }; };
  const isSchool = (url) => SCHOOL.some((d) => match(host(url), d));
  const text = (v) => String(v || "").replace(/\s+/g, " ").trim();
  const wc = (v) => text(v) ? text(v).split(/\s+/).length : 0;
  const pv = (v) => text(v).slice(0, 160);
  const id = (p) => `${p}_${crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
  const fp = (v) => text(v).toLowerCase().replace(/[^\w\s]/g, "").slice(0, 120);
  const words = (v) => text(v).toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/).filter((w) => w.length > 3).slice(0, 80);
  const send = (m) => chrome.runtime.sendMessage({ source: "esa-dome-content", ...m }, () => void chrome.runtime.lastError);
  const selected = () => text(window.getSelection ? window.getSelection().toString() : "");
  const activeText = () => {
    const el = document.activeElement;
    if (!el) return "";
    if ("value" in el) return text(el.value);
    return text(el.innerText || el.textContent || "");
  };
  const copiedText = () => selected() || activeText();

  function classify(v) {
    const l = text(v).toLowerCase();
    if (["write my essay", "avoid ai detection", "do my homework", "answer this quiz"].some((x) => l.includes(x))) return { category: "academic_integrity_risk", riskLevel: "high", summary: "High-risk academic integrity prompt detected." };
    if (["solve", "homework", "assignment", "equation", "math"].some((x) => l.includes(x))) return { category: "homework_help", riskLevel: "medium", summary: "Homework-related AI use detected." };
    return { category: "general_ai_use", riskLevel: "low", summary: "Monitored AI or schoolwork activity detected." };
  }

  let timer;
  document.addEventListener("input", (e) => {
    const ai = aiFor(location.href);
    if (!ai) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      const value = text(e.target && ("value" in e.target ? e.target.value : e.target.innerText));
      if (value.length < 20) return;
      const c = classify(value);
      send({ action: "saveEvent", event: { id: id("prompt"), type: "ai_prompt_detected", ...ai, url: location.href, timestamp: new Date().toISOString(), promptPreview: pv(value), wordCount: wc(value), ...c } });
    }, 1500);
  }, true);

  function recordCopy(value, method) {
    const ai = aiFor(location.href);
    const school = isSchool(location.href);
    if (!ai && !school) return;
    const c = classify(value);
    const event = { id: id("copy"), type: ai ? "ai_text_copied" : "schoolwork_copy_detected", aiTool: ai && ai.aiTool, domain: host(location.href), url: location.href, timestamp: new Date().toISOString(), copiedPreview: pv(value), wordCount: wc(value), confidence: "medium", captureMethod: method, ...c };
    if (ai && value.length >= 30) send({ action: "saveCopiedAIText", recentCopiedAIText: { sourceAiTool: ai.aiTool, copiedPreview: pv(value), fingerprint: fp(value), tokens: words(value), wordCount: wc(value), category: c.category, timestamp: event.timestamp }, event });
    else send({ action: "saveEvent", event });
  }

  function tokenSimilarity(value, recent) {
    const recentTokens = Array.isArray(recent.tokens) ? recent.tokens : [];
    const currentTokens = new Set(words(value));
    if (!recentTokens.length || !currentTokens.size) return 0;
    const overlap = recentTokens.filter((token) => currentTokens.has(token)).length;
    return overlap / Math.min(recentTokens.length, currentTokens.size);
  }

  async function recordPaste(value, method) {
    const ai = aiFor(location.href);
    const school = isSchool(location.href);
    if (!ai && !school) return;
    value = text(value);
    const state = await new Promise((r) => chrome.storage.local.get(["recentCopiedAIText", "lastSelectedAIText"], r));
    const recent = state.recentCopiedAIText || state.lastSelectedAIText || {};
    const fromAi = school && value.length >= 30 && recent.fingerprint && (fp(value).includes(recent.fingerprint.slice(0, 40)) || tokenSimilarity(value, recent) >= 0.35);
    const c = classify(value);
    send({ action: "saveEvent", event: { id: id("paste"), type: fromAi ? "ai_text_pasted_to_schoolwork" : (school ? "schoolwork_paste_detected" : "ai_paste_detected"), sourceAiTool: recent.sourceAiTool, domain: host(location.href), destinationDomain: host(location.href), destinationUrl: location.href, timestamp: new Date().toISOString(), pastedPreview: pv(value), wordCount: wc(value), riskLevel: fromAi ? "high" : c.riskLevel, category: recent.category || c.category, summary: fromAi ? "Likely AI text pasted into schoolwork." : c.summary, confidence: fromAi ? "medium" : "low", captureMethod: method } });
  }

  document.addEventListener("copy", () => {
    recordCopy(copiedText(), "copy_event");
  }, true);

  document.addEventListener("paste", async (e) => {
    recordPaste(e.clipboardData && e.clipboardData.getData("text"), "paste_event");
  }, true);

  document.addEventListener("beforeinput", async (e) => {
    if (e.inputType === "insertFromPaste" && e.data) {
      recordPaste(e.data, "beforeinput_paste");
    }
  }, true);

  document.addEventListener("keydown", (e) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    const key = String(e.key || "").toLowerCase();
    if (key === "c") {
      setTimeout(() => recordCopy(copiedText(), "keyboard_copy_fallback"), 80);
    }
    if (key === "v" && navigator.clipboard && navigator.clipboard.readText) {
      setTimeout(() => {
        navigator.clipboard.readText().then((value) => recordPaste(value, "keyboard_paste_fallback")).catch(() => {});
      }, 120);
    }
  }, true);

  document.addEventListener("mouseup", () => {
    const ai = aiFor(location.href);
    if (!ai) return;
    const value = selected();
    if (value.length >= 30) {
      chrome.storage.local.set({ lastSelectedAIText: { sourceAiTool: ai.aiTool, copiedPreview: pv(value), fingerprint: fp(value), tokens: words(value), wordCount: wc(value), timestamp: new Date().toISOString() } });
    }
  }, true);
})();
