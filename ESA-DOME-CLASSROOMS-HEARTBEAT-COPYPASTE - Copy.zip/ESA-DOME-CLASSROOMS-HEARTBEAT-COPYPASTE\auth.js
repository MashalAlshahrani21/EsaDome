/* global ESAFirebase */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const status = $("authStatus");
  const show = (m, err) => { status.hidden = false; status.className = err ? "scan-result high" : "scan-result"; status.textContent = m; };
  const creds = () => ({ email: $("email").value.trim(), password: $("password").value });
  async function applyRole() {
    await ESAFirebase.saveSettings({ accountRole: $("accountRole").value });
  }
  $("signIn").onclick = async () => { try { await applyRole(); const c = creds(); const u = await ESAFirebase.signInWithEmail(c.email, c.password); await ESAFirebase.syncPendingEvents(); show(`Signed in as ${u.email}.`, false); } catch (e) { show(e.message, true); } };
  $("signUp").onclick = async () => { try { await applyRole(); const c = creds(); const u = await ESAFirebase.signUpWithEmail(c.email, c.password); await ESAFirebase.syncPendingEvents(); show(`Account created for ${u.email}.`, false); } catch (e) { show(e.message, true); } };
  $("createStudent").onclick = async () => { try { await ESAFirebase.saveSettings({ accountRole: "guardian" }); const student = await ESAFirebase.createGuardianStudent($("studentNameSetup").value.trim() || "Student", $("classroomNameSetup").value.trim() || "Default Class"); show(`Student created in ${student.classroomName}. Give this code to the student device: ${student.joinCode}`, false); } catch (e) { show(e.message, true); } };
  $("joinStudent").onclick = async () => { try { await ESAFirebase.saveSettings({ accountRole: "student", cloudSyncEnabled: true, monitoringEnabled: true }); const join = await ESAFirebase.joinStudentWithCode($("joinCode").value); await ESAFirebase.syncPendingEvents(); show(`Student device linked to ${join.guardianEmail}. Auto-sync is on.`, false); } catch (e) { show(e.message, true); } };
  $("signOut").onclick = async () => { await ESAFirebase.clearAuthUser(); show("Signed out.", false); };
  Promise.all([ESAFirebase.getAuthUser(), ESAFirebase.getSettings()]).then(([u, settings]) => {
    $("accountRole").value = settings.accountRole || "guardian";
    $("studentNameSetup").value = settings.studentName || "";
    $("classroomNameSetup").value = settings.classroomName || "";
    $("joinCode").value = settings.joinCode || "";
    if (u) { $("email").value = u.email; show(`Currently signed in as ${u.email}.`, false); }
  });
})();
