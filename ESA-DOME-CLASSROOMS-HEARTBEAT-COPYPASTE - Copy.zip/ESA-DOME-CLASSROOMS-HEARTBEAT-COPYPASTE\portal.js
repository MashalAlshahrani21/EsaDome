/* global ESAFirebase */
(function () {
  "use strict";

  const statusCard = document.getElementById("statusCard");
  const checkNow = document.getElementById("checkNow");

  function minutesAgo(iso) {
    if (!iso) return Infinity;
    return (Date.now() - new Date(iso).getTime()) / 60000;
  }

  async function checkSession() {
    const authUser = await ESAFirebase.getAuthUser();
    const settings = await ESAFirebase.getSettings();
    const state = await ESAFirebase.storageGet(["lastHeartbeatAt"]);
    let heartbeat = null;
    try {
      heartbeat = await ESAFirebase.sendHeartbeat();
    } catch (error) {}

    const lastHeartbeatAt = heartbeat ? heartbeat.lastActiveAt : state.lastHeartbeatAt;
    const fresh = minutesAgo(lastHeartbeatAt) <= 2;
    const installed = true;
    const signedIn = Boolean(authUser);
    const linked = settings.accountRole !== "student" || Boolean(settings.guardianUid);
    const allowedBrowser = /Chrome|Chromium|Edg/.test(navigator.userAgent);
    const trusted = installed && signedIn && linked && fresh && allowedBrowser;

    statusCard.className = `card ${trusted ? "trusted" : "untrusted"}`;
    statusCard.textContent = [
      trusted ? "SESSION TRUSTED" : "SESSION NOT TRUSTED",
      "",
      `Extension installed: ${installed ? "yes" : "no"}`,
      `Signed in: ${signedIn ? authUser.email : "no"}`,
      `Student linked: ${linked ? "yes" : "no"}`,
      `Allowed browser: ${allowedBrowser ? "yes" : "no"}`,
      `Last heartbeat: ${lastHeartbeatAt || "never"}`,
      "",
      trusted ? "The student can continue in a protected portal flow." : "Require sign-in/reconnect before quizzes or exams."
    ].join("\n");
  }

  checkNow.onclick = checkSession;
  checkSession();
})();
