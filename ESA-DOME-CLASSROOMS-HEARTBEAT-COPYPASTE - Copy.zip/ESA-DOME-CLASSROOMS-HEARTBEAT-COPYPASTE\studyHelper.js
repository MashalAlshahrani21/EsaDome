/* global ESAFirebase, ESA_AI_CONFIG */
(function () {
  "use strict";

  const chat = document.getElementById("chat");
  const form = document.getElementById("helperForm");
  const questionInput = document.getElementById("question");

  function addBubble(text, kind) {
    const bubble = document.createElement("div");
    bubble.className = `bubble ${kind}`;
    bubble.textContent = text;
    chat.appendChild(bubble);
    bubble.scrollIntoView({ behavior: "smooth", block: "end" });
  }

  function hasGeminiKey() {
    return Boolean(
      typeof ESA_AI_CONFIG !== "undefined" &&
      ESA_AI_CONFIG.geminiApiKey &&
      !String(ESA_AI_CONFIG.geminiApiKey).includes("PASTE_")
    );
  }

  async function askGemini(question) {
    if (!hasGeminiKey()) {
      throw new Error("Gemini key is missing in aiConfig.js.");
    }

    const prompt = [
      "You are ESA DOME Study Helper, a student-safe study coach.",
      "Do not write final answers, essays, quiz answers, or completed homework.",
      "Give where to look, credible source suggestions, search terms, guiding questions, and short concept explanations.",
      "If the student asks for a direct answer, politely refuse and guide them toward learning.",
      "Use simple language.",
      "",
      "Student question:",
      question
    ].join("\n");

    const model = ESA_AI_CONFIG.model || "gemini-2.5-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": ESA_AI_CONFIG.geminiApiKey
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.4 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error((data.error && data.error.message) || "Study Helper failed.");
    }
    return data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text;
  }

  async function saveStudyEvent(question, answer) {
    const state = await ESAFirebase.storageGet(["events"]);
    const events = Array.isArray(state.events) ? state.events : [];
    const event = {
      id: `study_${crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now()}`,
      type: "study_helper_used",
      timestamp: new Date().toISOString(),
      category: "study_support",
      riskLevel: "low",
      summary: "Student used Study Helper for guided research support.",
      wordCount: question.split(/\s+/).filter(Boolean).length,
      promptPreview: "[preview disabled]",
      responsePreview: "[preview disabled]",
      synced: false
    };
    await ESAFirebase.storageSet({ events: [event, ...events].slice(0, 500) });
    await ESAFirebase.syncPendingEvents();
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const question = questionInput.value.trim();
    if (!question) return;
    questionInput.value = "";
    addBubble(question, "user");
    addBubble("Thinking...", "assistant");
    const thinking = chat.lastElementChild;
    try {
      const answer = await askGemini(question);
      thinking.textContent = answer || "I could not generate a study guide response.";
      await saveStudyEvent(question, answer || "");
    } catch (error) {
      thinking.textContent = error.message;
    }
  });

  addBubble("Hi. Ask me where to look, what terms to search, or what questions to think about. I will help you study without writing the final answer.", "assistant");
})();
