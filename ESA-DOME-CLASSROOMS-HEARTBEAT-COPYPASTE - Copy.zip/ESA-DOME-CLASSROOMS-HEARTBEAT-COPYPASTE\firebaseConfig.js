/* global self */
(function () {
  "use strict";

  self.ESA_FIREBASE_CONFIG = {
    apiKey: "AIzaSyB-xaq_iPpd_4ECaq4TM3vmb6kqEU0F4KE",
    authDomain: "esa-dome.firebaseapp.com",
    projectId: "esa-dome"
  };
})();
