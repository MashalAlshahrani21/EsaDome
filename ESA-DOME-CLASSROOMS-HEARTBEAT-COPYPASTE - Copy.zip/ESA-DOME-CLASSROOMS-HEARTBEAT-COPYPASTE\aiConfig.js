/* global self */
(function () {
  "use strict";

  /*
   * Private prototype only:
   * Paste your Gemini API key below.
   *
   * Do not publish this extension publicly with the key inside.
   * For production, move Gemini calls to a secure backend.
   */
  self.ESA_AI_CONFIG = {
    geminiApiKey: "AIzaSyBUfNmuhB5lm0N1C8fMy2Z_pceD005hdhY",
    model: "gemini-2.5-flash"
  };
})();
