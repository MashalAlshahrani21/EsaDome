/* global ESAFirebase */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  let all = [];
  let local = [];
  let sessions = [];
  let students = [];
  let selectedStudentId = "";

  function isCopy(event) {
    return String(event.type || "").includes("copy") || String(event.type || "").includes("paste");
  }

  function shown(event) {
    if (selectedStudentId && event.studentId !== selectedStudentId) return false;
    const filter = $("filter").value;
    return filter === "all" ||
      (filter === "local" && !event.cloud) ||
      (filter === "synced" && (event.cloud || event.synced)) ||
      (filter === "unsynced" && !event.cloud && !event.synced) ||
      (filter === "high" && event.riskLevel === "high") ||
      (filter === "copy" && isCopy(event)) ||
      (filter === "visit" && event.type === "ai_site_visit");
  }

  function latestSessionFor(studentId) {
    return sessions
      .filter((session) => session.studentId === studentId)
      .sort((a, b) => String(b.lastActiveAt || "").localeCompare(String(a.lastActiveAt || "")))[0];
  }

  function heartbeatText(session) {
    if (!session || !session.lastActiveAt) return "untrusted - no heartbeat";
    const age = Math.round((Date.now() - new Date(session.lastActiveAt).getTime()) / 60000);
    return age <= 2 ? `trusted - heartbeat ${age} min ago` : `untrusted - heartbeat ${age} min ago`;
  }

  function renderStudents() {
    const grouped = new Map();

    for (const student of students) {
      grouped.set(student.studentId, {
        studentId: student.studentId,
        studentName: student.studentName || "Student",
        classroomName: student.classroomName || "Unassigned",
        total: 0,
        high: 0,
        visits: 0,
        copy: 0,
        latestSession: latestSessionFor(student.studentId)
      });
    }

    for (const event of all.filter((item) => item.studentId)) {
      const current = grouped.get(event.studentId) || {
        studentId: event.studentId,
        studentName: event.studentName || "Student",
        classroomName: event.classroomName || "Unassigned",
        total: 0,
        high: 0,
        visits: 0,
        copy: 0,
        latestSession: latestSessionFor(event.studentId)
      };
      current.total += 1;
      if (event.riskLevel === "high") current.high += 1;
      if (event.type === "ai_site_visit") current.visits += 1;
      if (isCopy(event)) current.copy += 1;
      grouped.set(event.studentId, current);
    }

    const byClassroom = {};
    for (const student of grouped.values()) {
      const classroom = student.classroomName || "Unassigned";
      byClassroom[classroom] = byClassroom[classroom] || [];
      byClassroom[classroom].push(student);
    }

    $("studentList").textContent = "";
    for (const classroom of Object.keys(byClassroom).sort()) {
      const heading = document.createElement("div");
      heading.className = "classroom-heading";
      heading.textContent = classroom;
      $("studentList").appendChild(heading);

      for (const student of byClassroom[classroom].sort((a, b) => a.studentName.localeCompare(b.studentName))) {
        const card = document.createElement("div");
        card.className = `student-card ${selectedStudentId === student.studentId ? "active" : ""}`;
        card.innerHTML = `<strong>${student.studentName}</strong><div class="student-meta">${student.studentId}</div><div>${student.total} events - ${student.visits} AI visits - ${student.copy} copy/paste - ${student.high} high risk</div><div class="student-meta">Session: ${heartbeatText(student.latestSession)}</div>`;
        const button = document.createElement("button");
        button.textContent = "View This Student";
        button.onclick = () => {
          selectedStudentId = student.studentId;
          renderStudents();
          render();
        };
        card.appendChild(button);
        $("studentList").appendChild(card);
      }
    }
  }

  function render() {
    const rows = all.filter(shown);
    $("rows").textContent = "";
    for (const event of rows) {
      const row = document.createElement("tr");
      [
        new Date(event.timestamp || "").toLocaleString(),
        `${event.studentName || "Student"} ${event.studentId ? `(${String(event.studentId).slice(0, 14)}...)` : ""}`,
        event.cloud ? "Cloud" : (event.synced ? "Local synced" : "Local unsynced"),
        event.type,
        event.aiTool || event.sourceAiTool || event.domain || "",
        event.riskLevel || "low",
        event.summary || "",
        event.preview || event.promptPreview || event.copiedPreview || event.pastedPreview || event.pageTextPreview || ""
      ].forEach((value, index) => {
        const cell = document.createElement("td");
        if (index === 5) {
          const badge = document.createElement("span");
          badge.className = `risk ${value}`;
          badge.textContent = value;
          cell.appendChild(badge);
        } else {
          cell.textContent = value || "";
        }
        row.appendChild(cell);
      });
      $("rows").appendChild(row);
    }
    $("emptyState").classList.toggle("visible", rows.length === 0);
  }

  async function load() {
    await ESAFirebase.syncPendingEvents();
    const settings = await ESAFirebase.getSettings();
    const user = await ESAFirebase.getAuthUser();
    const state = await ESAFirebase.storageGet(["events"]);
    local = Array.isArray(state.events) ? state.events : [];
    const isGuardian = user && settings.accountRole !== "student";
    const cloud = isGuardian ? await ESAFirebase.fetchAllGuardianEvents().catch(() => []) : [];
    sessions = isGuardian ? await ESAFirebase.fetchAllGuardianSessions().catch(() => []) : [];
    students = isGuardian ? await ESAFirebase.fetchAllGuardianStudents().catch(() => []) : [];
    all = [
      ...local.map((event) => ({ ...event, studentName: settings.studentName, studentId: settings.studentId, classroomName: settings.classroomName || "Local" })),
      ...cloud
    ].sort((a, b) => String(b.timestamp).localeCompare(String(a.timestamp)));

    $("studentLabel").textContent = `Student: ${settings.studentName} (${settings.studentId})`;
    $("syncLabel").textContent = user ? (settings.accountRole === "student" ? `Signed in as student: ${user.email}` : `Signed in: ${user.email} - showing all classrooms and students`) : "Signed out";
    $("clearEvents").style.display = settings.accountRole === "student" ? "none" : "";
    $("totalEvents").textContent = all.length;
    $("cloudEvents").textContent = cloud.length;
    $("studentCount").textContent = students.length || new Set(cloud.map((event) => event.studentId).filter(Boolean)).size;
    $("unsyncedEvents").textContent = local.filter((event) => !event.synced).length;
    $("highRiskEvents").textContent = all.filter((event) => event.riskLevel === "high").length;
    $("studentSection").style.display = settings.accountRole === "student" ? "none" : "";
    $("lockSection").style.display = settings.accountRole === "student" ? "none" : "";
    renderStudents();
    render();
  }

  $("filter").onchange = render;
  $("refresh").onclick = load;
  $("showAllStudents").onclick = () => {
    selectedStudentId = "";
    renderStudents();
    render();
  };
  $("browserLockInfo").onclick = () => alert("A normal Chrome extension cannot force a student to stay inside Chrome. Use ChromeOS kiosk mode, managed Chrome policies, Family Link, Windows assigned access, Apple Screen Time/MDM, or a school device-management system.");
  $("exportJson").onclick = () => {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([JSON.stringify(all, null, 2)], { type: "application/json" }));
    link.download = "esa-dome-events.json";
    link.click();
  };
  $("clearEvents").onclick = async () => {
    if (confirm("Clear local events?")) {
      await ESAFirebase.storageSet({ events: [] });
      load();
    }
  };
  load();
})();
