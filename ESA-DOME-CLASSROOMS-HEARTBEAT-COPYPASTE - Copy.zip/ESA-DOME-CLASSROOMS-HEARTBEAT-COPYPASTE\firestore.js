/* global chrome, ESA_FIREBASE_CONFIG */
(function () {
  "use strict";

  const DEFAULT_SETTINGS = {
    studentName: "Student",
    studentId: "",
    guardianUid: "",
    accountRole: "guardian",
    joinCode: "",
    linkedGuardianEmail: "",
    deviceId: "",
    classroomId: "",
    classroomName: "",
    monitoringEnabled: true,
    cloudSyncEnabled: true,
    storeTextPreviews: false
  };

  const getConfig = () => {
    if (typeof self !== "undefined" && self.ESA_FIREBASE_CONFIG) return self.ESA_FIREBASE_CONFIG;
    if (typeof ESA_FIREBASE_CONFIG !== "undefined") return ESA_FIREBASE_CONFIG;
    return {};
  };
  const configured = () => {
    const c = getConfig();
    return Boolean(c.apiKey && c.projectId && !String(c.apiKey).includes("PASTE_"));
  };
  const storageGet = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, (r) => resolve(r || {})));
  const storageSet = (value) => new Promise((resolve) => chrome.storage.local.set(value, resolve));
  const id = () => crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}_${Math.random().toString(36).slice(2)}`;

  async function getSettings() {
    const s = await storageGet(["settings"]);
    const settings = { ...DEFAULT_SETTINGS, ...(s.settings || {}) };
    if (!settings.studentId) {
      settings.studentId = `student_${id()}`;
      await storageSet({ settings });
    }
    if (!settings.deviceId) {
      settings.deviceId = `device_${id()}`;
      await storageSet({ settings });
    }
    return settings;
  }

  async function saveSettings(patch) {
    const settings = { ...(await getSettings()), ...patch };
    await storageSet({ settings });
    return settings;
  }

  const authUrl = (path) => `https://identitytoolkit.googleapis.com/v1/${path}?key=${encodeURIComponent(getConfig().apiKey || "")}`;
  const tokenUrl = () => `https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(getConfig().apiKey || "")}`;
  const baseUrl = () => `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(getConfig().projectId || "")}/databases/(default)/documents`;

  async function authRequest(path, body) {
    if (!configured()) throw new Error("Firebase is not configured.");
    const res = await fetch(authUrl(path), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error((data.error && data.error.message) || "Firebase Auth failed.");
    return data;
  }

  async function saveAuth(data) {
    const authUser = {
      uid: data.localId,
      email: data.email,
      idToken: data.idToken,
      refreshToken: data.refreshToken,
      expiresAt: Date.now() + Number(data.expiresIn || 3600) * 1000
    };
    await storageSet({ authUser });
    const settings = await getSettings();
    if (settings.accountRole !== "student") {
      await saveSettings({ guardianUid: authUser.uid, accountRole: "guardian" });
      await ensureUserAndStudent();
    }
    return authUser;
  }

  const signUpWithEmail = (email, password) => authRequest("accounts:signUp", { email, password, returnSecureToken: true }).then(saveAuth);
  const signInWithEmail = (email, password) => authRequest("accounts:signInWithPassword", { email, password, returnSecureToken: true }).then(saveAuth);
  const getAuthUser = async () => (await storageGet(["authUser"])).authUser || null;
  const clearAuthUser = () => storageSet({ authUser: null });

  async function getFreshAuthUser() {
    const user = await getAuthUser();
    if (!user) return null;
    if (user.expiresAt && Date.now() < user.expiresAt - 60000) return user;
    const res = await fetch(tokenUrl(), {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: user.refreshToken })
    });
    const data = await res.json();
    if (!res.ok) throw new Error((data.error && data.error.message) || "Could not refresh sign-in.");
    const next = { uid: data.user_id, email: user.email, idToken: data.id_token, refreshToken: data.refresh_token, expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000 };
    await storageSet({ authUser: next });
    return next;
  }

  function value(v) {
    if (v === undefined || v === null) return { nullValue: null };
    if (typeof v === "boolean") return { booleanValue: v };
    if (typeof v === "number") return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
    if (Array.isArray(v)) return { arrayValue: { values: v.map(value) } };
    if (typeof v === "object") return { mapValue: { fields: fields(v) } };
    return { stringValue: String(v) };
  }
  const fields = (o) => Object.fromEntries(Object.entries(o || {}).filter((e) => e[1] !== undefined).map(([k, v]) => [k, value(v)]));
  const fromValue = (v) => v.stringValue ?? (v.integerValue ? Number(v.integerValue) : v.doubleValue ?? v.booleanValue ?? null);
  const fromFields = (f) => Object.fromEntries(Object.entries(f || {}).map(([k, v]) => [k, fromValue(v)]));

  async function request(path, options) {
    const user = await getFreshAuthUser();
    if (!user) throw new Error("Not signed in.");
    const res = await fetch(`${baseUrl()}/${path}`, {
      ...options,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${user.idToken}` }
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data.error && data.error.message) || "Firestore request failed.");
    return data;
  }

  const enc = (s) => encodeURIComponent(String(s || ""));
  const upsert = (path, object) => request(path, { method: "PATCH", body: JSON.stringify({ fields: fields(object) }) });

  async function ensureUserAndStudent() {
    const user = await getFreshAuthUser();
    if (!user) return;
    const settings = await getSettings();
    const guardianUid = settings.accountRole === "student" && settings.guardianUid ? settings.guardianUid : user.uid;
    await upsert(`users/${enc(user.uid)}`, { email: user.email, accountRole: settings.accountRole, createdAt: new Date().toISOString() });
    if (settings.accountRole === "student" && !settings.guardianUid) return;
    await upsert(`users/${enc(guardianUid)}/students/${enc(settings.studentId)}`, {
      studentName: settings.studentName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      guardianUid,
      studentUid: settings.accountRole === "student" ? user.uid : settings.studentUid,
      joinCode: settings.joinCode,
      classroomId: settings.classroomId,
      classroomName: settings.classroomName,
      monitoringEnabled: settings.monitoringEnabled,
      storeTextPreviews: settings.storeTextPreviews
    });
  }

  function makeJoinCode() {
    return `ESA-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  }

  function classroomIdFromName(classroomName) {
    const clean = String(classroomName || "Default Class").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    return `class_${clean || "default"}`;
  }

  async function createGuardianStudent(studentName, classroomName) {
    const user = await getFreshAuthUser();
    if (!user) throw new Error("Sign in as a parent or teacher first.");
    const studentId = `student_${id()}`;
    const joinCode = makeJoinCode();
    const finalClassroomName = classroomName || "Default Class";
    const classroomId = classroomIdFromName(finalClassroomName);
    await saveSettings({ accountRole: "guardian", guardianUid: user.uid, studentName: studentName || "Student", studentId, joinCode, classroomId, classroomName: finalClassroomName });
    await upsert(`users/${enc(user.uid)}`, { email: user.email, accountRole: "guardian", createdAt: new Date().toISOString() });
    await upsert(`users/${enc(user.uid)}/classrooms/${enc(classroomId)}`, {
      classroomId,
      classroomName: finalClassroomName,
      guardianUid: user.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    await upsert(`users/${enc(user.uid)}/students/${enc(studentId)}`, {
      studentName: studentName || "Student",
      guardianUid: user.uid,
      classroomId,
      classroomName: finalClassroomName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      monitoringEnabled: true,
      storeTextPreviews: false,
      joinCode
    });
    await upsert(`joinCodes/${enc(joinCode)}`, {
      joinCode,
      guardianUid: user.uid,
      guardianEmail: user.email,
      studentId,
      studentName: studentName || "Student",
      classroomId,
      classroomName: finalClassroomName,
      createdAt: new Date().toISOString(),
      active: true
    });
    return { joinCode, studentId, studentName: studentName || "Student", classroomId, classroomName: finalClassroomName };
  }

  async function getDocument(path) {
    return request(path, { method: "GET" });
  }

  async function joinStudentWithCode(joinCode) {
    const user = await getFreshAuthUser();
    if (!user) throw new Error("Sign in with the student account first.");
    const cleanCode = String(joinCode || "").trim().toUpperCase();
    if (!cleanCode) throw new Error("Enter a join code.");
    const data = await getDocument(`joinCodes/${enc(cleanCode)}`);
    const join = fromFields(data.fields || {});
    if (!join.active) throw new Error("This join code is not active.");
    await saveSettings({
      accountRole: "student",
      guardianUid: join.guardianUid,
      linkedGuardianEmail: join.guardianEmail,
      studentId: join.studentId,
      studentName: join.studentName || "Student",
      classroomId: join.classroomId || "",
      classroomName: join.classroomName || "",
      joinCode: cleanCode,
      cloudSyncEnabled: true
    });
    await upsert(`users/${enc(user.uid)}`, { email: user.email, accountRole: "student", linkedGuardianUid: join.guardianUid, createdAt: new Date().toISOString() });
    await upsert(`users/${enc(join.guardianUid)}/students/${enc(join.studentId)}`, {
      studentName: join.studentName || "Student",
      guardianUid: join.guardianUid,
      classroomId: join.classroomId || "",
      classroomName: join.classroomName || "",
      studentUid: user.uid,
      studentEmail: user.email,
      joinCode: cleanCode,
      updatedAt: new Date().toISOString(),
      monitoringEnabled: true,
      storeTextPreviews: false
    });
    return join;
  }

  function uploadShape(event, settings) {
    return {
      id: event.id,
      type: event.type,
      aiTool: event.aiTool,
      sourceAiTool: event.sourceAiTool,
      domain: event.domain,
      url: event.url,
      destinationDomain: event.destinationDomain,
      destinationUrl: event.destinationUrl,
      timestamp: event.timestamp,
      category: event.category,
      riskLevel: event.riskLevel,
      summary: event.summary,
      wordCount: event.wordCount,
      preview: settings.storeTextPreviews ? (event.preview || event.promptPreview || event.copiedPreview || event.pastedPreview || "") : "[preview disabled]",
      confidence: event.confidence,
      syncedAt: new Date().toISOString()
    };
  }

  async function uploadEvent(event) {
    const user = await getFreshAuthUser();
    const settings = await getSettings();
    if (!user || !settings.cloudSyncEnabled || !configured()) throw new Error("Cloud sync unavailable.");
    await ensureUserAndStudent();
    const doc = uploadShape(event, settings);
    const guardianUid = settings.accountRole === "student" && settings.guardianUid ? settings.guardianUid : user.uid;
    await upsert(`users/${enc(guardianUid)}/students/${enc(settings.studentId)}/events/${enc(event.id)}`, {
      ...doc,
      studentId: settings.studentId,
      studentName: settings.studentName,
      classroomId: settings.classroomId,
      classroomName: settings.classroomName,
      uploaderUid: user.uid,
      accountRole: settings.accountRole
    });
    return doc.syncedAt;
  }

  async function syncPendingEvents() {
    const state = await storageGet(["events"]);
    const events = Array.isArray(state.events) ? state.events : [];
    let syncedCount = 0;
    let lastSyncedAt = "";
    for (const event of events.filter((e) => e.synced !== true)) {
      try {
        lastSyncedAt = await uploadEvent(event);
        event.synced = true;
        event.syncedAt = lastSyncedAt;
        syncedCount += 1;
      } catch (error) {}
    }
    await storageSet({ events, lastSyncedAt });
    return { syncedCount, lastSyncedAt };
  }

  async function sendHeartbeat() {
    const user = await getFreshAuthUser();
    const settings = await getSettings();
    if (!user || !settings.cloudSyncEnabled || !configured()) throw new Error("Heartbeat unavailable.");
    if (settings.accountRole === "student" && !settings.guardianUid) throw new Error("Student device is not linked.");
    await ensureUserAndStudent();
    const guardianUid = settings.accountRole === "student" && settings.guardianUid ? settings.guardianUid : user.uid;
    const heartbeat = {
      deviceId: settings.deviceId,
      studentId: settings.studentId,
      studentName: settings.studentName,
      classroomId: settings.classroomId,
      classroomName: settings.classroomName,
      accountRole: settings.accountRole,
      uploaderUid: user.uid,
      email: user.email,
      userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "extension-service-worker",
      lastActiveAt: new Date().toISOString(),
      status: "trusted"
    };
    await upsert(`users/${enc(guardianUid)}/students/${enc(settings.studentId)}/sessions/${enc(settings.deviceId)}`, heartbeat);
    await storageSet({ lastHeartbeatAt: heartbeat.lastActiveAt });
    return heartbeat;
  }

  async function fetchCloudEvents() {
    const user = await getFreshAuthUser();
    const settings = await getSettings();
    if (!user) return [];
    const data = await request(`users/${enc(user.uid)}/students/${enc(settings.studentId)}/events`, { method: "GET" });
    return (data.documents || []).map((doc) => ({ ...fromFields(doc.fields || {}), cloud: true }));
  }

  async function fetchAllGuardianEvents() {
    const user = await getFreshAuthUser();
    if (!user) return [];
    const studentsData = await request(`users/${enc(user.uid)}/students`, { method: "GET" });
    const students = studentsData.documents || [];
    const allEvents = [];

    for (const studentDoc of students) {
      const studentId = String(studentDoc.name || "").split("/").pop();
      const student = fromFields(studentDoc.fields || {});
      try {
        const eventsData = await request(`users/${enc(user.uid)}/students/${enc(studentId)}/events`, { method: "GET" });
        for (const eventDoc of eventsData.documents || []) {
          allEvents.push({
            ...fromFields(eventDoc.fields || {}),
            cloud: true,
            studentId,
            studentName: student.studentName || "Student",
            classroomId: student.classroomId || "",
            classroomName: student.classroomName || "Unassigned"
          });
        }
      } catch (error) {
        // Keep the dashboard usable if one student/device collection fails.
      }
    }

    return allEvents;
  }

  async function fetchAllGuardianSessions() {
    const user = await getFreshAuthUser();
    if (!user) return [];
    const studentsData = await request(`users/${enc(user.uid)}/students`, { method: "GET" });
    const sessions = [];
    for (const studentDoc of studentsData.documents || []) {
      const studentId = String(studentDoc.name || "").split("/").pop();
      const student = fromFields(studentDoc.fields || {});
      try {
        const data = await request(`users/${enc(user.uid)}/students/${enc(studentId)}/sessions`, { method: "GET" });
        for (const sessionDoc of data.documents || []) sessions.push({ ...fromFields(sessionDoc.fields || {}), studentId, studentName: student.studentName || "Student" });
      } catch (error) {}
    }
    return sessions;
  }

  async function fetchAllGuardianStudents() {
    const user = await getFreshAuthUser();
    if (!user) return [];
    const studentsData = await request(`users/${enc(user.uid)}/students`, { method: "GET" });
    return (studentsData.documents || []).map((doc) => {
      const studentId = String(doc.name || "").split("/").pop();
      return { ...fromFields(doc.fields || {}), studentId };
    });
  }

  self.ESAFirebase = { clearAuthUser, configured, createGuardianStudent, fetchAllGuardianEvents, fetchAllGuardianSessions, fetchAllGuardianStudents, fetchCloudEvents, getAuthUser, getFreshAuthUser, getSettings, joinStudentWithCode, saveSettings, sendHeartbeat, signInWithEmail, signUpWithEmail, storageGet, storageSet, syncPendingEvents, uploadEvent };
})();
