/* global chrome, ESAFirebase, ESA_AI_CONFIG */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const panels = {
    overview: $("panelOverview"),
    study: $("panelStudy"),
    account: $("panelAccount")
  };
  const tabs = {
    overview: $("tabOverview"),
    study: $("tabStudy"),
    account: $("tabAccount")
  };

  function showTab(name) {
    Object.entries(panels).forEach(([key, panel]) => panel.classList.toggle("active", key === name));
    Object.entries(tabs).forEach(([key, tab]) => tab.classList.toggle("active", key === name));
  }

  function show(message, isError) {
    const el = $("message");
    el.hidden = false;
    el.className = isError ? "scan-result high" : "scan-result";
    el.textContent = message;
  }

  function send(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ source: "esa-dome-popup", ...message }, (response) => {
        resolve(response || { ok: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
      });
    });
  }

  function setVisible(id, visible) {
    $(id).style.display = visible ? "" : "none";
  }

  async function load() {
    const settings = await ESAFirebase.getSettings();
    const user = await ESAFirebase.getAuthUser();
    const state = await ESAFirebase.storageGet(["events"]);
    const events = Array.isArray(state.events) ? state.events : [];
    const isStudent = settings.accountRole === "student";

    $("authLine").textContent = user ? `${isStudent ? "Student" : "Guardian"}: ${user.email}` : "Sign in to sync";
    setVisible("signIn", !user);
    setVisible("signOut", Boolean(user));
    $("monitoringToggle").checked = settings.monitoringEnabled;
    $("cloudSyncEnabled").checked = settings.cloudSyncEnabled;
    $("storeTextPreviews").checked = settings.storeTextPreviews;
    $("studentName").value = settings.studentName;
    $("accountLink").value = isStudent ? `Linked to ${settings.linkedGuardianEmail || settings.guardianUid || "guardian"}` : `Guardian code: ${settings.joinCode || "create in Sign In"}`;
    $("statusText").textContent = settings.monitoringEnabled ? "Enabled" : "Paused";
    $("syncStatus").textContent = user ? `Unsynced: ${events.filter((event) => event.synced !== true).length}` : "Local fallback";
    $("todayCount").textContent = events.filter((event) => String(event.timestamp || "").startsWith(new Date().toISOString().slice(0, 10))).length;
    $("unsyncedCount").textContent = events.filter((event) => event.synced !== true).length;
    $("highRiskCount").textContent = events.filter((event) => event.riskLevel === "high").length;

    setVisible("statsSection", !isStudent);
    setVisible("openDashboard", !isStudent);
    setVisible("openPortal", !isStudent);
    setVisible("scanPage", !isStudent);
    setVisible("aiReviewPage", !isStudent);
    setVisible("clearEvents", !isStudent);
    $("cloudSyncEnabled").disabled = isStudent;
    $("monitoringToggle").disabled = isStudent;
    $("storeTextPreviews").disabled = isStudent;
    $("signOut").textContent = isStudent ? "Guardian Logout" : "Sign Out";
  }

  async function save(patch) {
    await ESAFirebase.saveSettings(patch);
    await load();
  }

  function addStudyBubble(text, kind) {
    const bubble = document.createElement("div");
    bubble.className = `bubble ${kind}`;
    bubble.textContent = text;
    $("studyChat").appendChild(bubble);
    $("studyChat").scrollTop = $("studyChat").scrollHeight;
    return bubble;
  }

  function geminiReady() {
    return Boolean(typeof ESA_AI_CONFIG !== "undefined" && ESA_AI_CONFIG.geminiApiKey && !String(ESA_AI_CONFIG.geminiApiKey).includes("PASTE_"));
  }

  async function askStudyHelper(question) {
    if (!geminiReady()) throw new Error("Gemini key is missing in aiConfig.js.");
    const prompt = [
      "You are ESA DOME Study Helper, a student-safe study coach.",
      "Do not write final answers, essays, quiz answers, or completed homework.",
      "Give source suggestions, search terms, hints, guiding questions, and short explanations.",
      "If asked for a direct answer, refuse briefly and guide the student.",
      "",
      "Student question:",
      question
    ].join("\n");
    const model = ESA_AI_CONFIG.model || "gemini-2.5-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": ESA_AI_CONFIG.geminiApiKey },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4 } })
    });
    const data = await response.json();
    if (!response.ok) throw new Error((data.error && data.error.message) || "Study Helper failed.");
    return data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text;
  }

  async function saveStudyEvent(question) {
    const state = await ESAFirebase.storageGet(["events"]);
    const events = Array.isArray(state.events) ? state.events : [];
    const event = {
      id: `study_${crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now()}`,
      type: "study_helper_used",
      timestamp: new Date().toISOString(),
      category: "study_support",
      riskLevel: "low",
      summary: "Student used Study Helper for guided research support.",
      wordCount: question.split(/\s+/).filter(Boolean).length,
      promptPreview: "[preview disabled]",
      synced: false
    };
    await ESAFirebase.storageSet({ events: [event, ...events].slice(0, 500) });
    await ESAFirebase.syncPendingEvents();
  }

  tabs.overview.onclick = () => showTab("overview");
  tabs.study.onclick = () => showTab("study");
  tabs.account.onclick = () => showTab("account");

  $("monitoringToggle").onchange = () => save({ monitoringEnabled: $("monitoringToggle").checked });
  $("cloudSyncEnabled").onchange = () => save({ cloudSyncEnabled: $("cloudSyncEnabled").checked });
  $("storeTextPreviews").onchange = () => save({ storeTextPreviews: $("storeTextPreviews").checked });
  $("studentName").onchange = () => save({ studentName: $("studentName").value.trim() || "Student" });
  $("signIn").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("auth.html") });
  $("signOut").onclick = async () => {
    const settings = await ESAFirebase.getSettings();
    if (settings.accountRole === "student") {
      const code = prompt("Guardian permission required. Enter the student join/unlock code.");
      if (!code || String(code).trim().toUpperCase() !== String(settings.joinCode || "").trim().toUpperCase()) {
        show("Logout blocked. Ask the teacher/parent for permission.", true);
        return;
      }
    }
    await ESAFirebase.clearAuthUser();
    show("Signed out.", false);
    await load();
  };
  $("syncNow").onclick = async () => { const res = await send({ action: "syncPendingEvents" }); show(res.ok ? `Synced ${res.result.syncedCount || 0} event(s).` : res.error, !res.ok); load(); };
  $("scanPage").onclick = async () => { const res = await send({ action: "scanActivePage" }); show(res.ok ? res.event.summary : res.error, !res.ok); load(); };
  $("aiReviewPage").onclick = async () => { show("Running Gemini AI review...", false); const res = await send({ action: "aiReviewActivePage" }); show(res.ok ? res.event.summary : res.error, !res.ok); load(); };
  $("openDashboard").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  $("openPortal").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("portal.html") });
  $("clearEvents").onclick = async () => { if (confirm("Clear local events?")) { await ESAFirebase.storageSet({ events: [], recentCopiedAIText: {} }); load(); } };

  $("studyForm").onsubmit = async (event) => {
    event.preventDefault();
    const question = $("studyQuestion").value.trim();
    if (!question) return;
    $("studyQuestion").value = "";
    addStudyBubble(question, "user");
    const reply = addStudyBubble("Thinking...", "assistant");
    try {
      const answer = await askStudyHelper(question);
      reply.textContent = answer || "I could not generate a study helper response.";
      await saveStudyEvent(question);
      await load();
    } catch (error) {
      reply.textContent = error.message;
    }
  };

  addStudyBubble("Ask me where to look, what search terms to use, or what questions to think about. I will help you study without writing the final answer.", "assistant");
  ESAFirebase.getSettings()
    .then((settings) => settings.accountRole === "student" ? ESAFirebase.saveSettings({ cloudSyncEnabled: true, monitoringEnabled: true }) : settings)
    .then(() => ESAFirebase.sendHeartbeat().catch(() => {}))
    .then(() => ESAFirebase.syncPendingEvents())
    .finally(load);
})();
