# ESA DOME

The Firebase config has already been added to `firebaseConfig.js`.

To use it:

1. Go to `chrome://extensions`.
2. Turn on Developer Mode.
3. Click Load unpacked.
4. Select this folder.
5. Open ESA DOME and click Sign In.

In Firebase Console, make sure Authentication > Sign-in method > Email/Password is enabled.

Firestore rules are in `firestore.rules`.

Gemini AI Review Scan:

1. Open `aiConfig.js`.
2. Replace `PASTE_GEMINI_API_KEY_HERE` with your Gemini API key.
3. Save the file.
4. Reload the extension in `chrome://extensions`.
5. Click `AI Review Scan` from the popup.

This is for private prototype testing only. Do not publish the extension with your Gemini key inside it.

Student mode:

- Students do not see Dashboard, Scan Page, AI Review Scan, Clear Events, or local risk counters.
- Students can open Study Helper.
- Student monitoring and cloud sync stay on.

Heartbeat/session verification:

- Student devices send a Firebase heartbeat about every minute.
- The teacher dashboard marks sessions as trusted when the heartbeat is recent.
- `portal.html` is a prototype verification portal that can block/allow a protected flow based on heartbeat status.
- If the extension is removed, closed, or signed out, the heartbeat stops and the session becomes untrusted.

Classrooms:

- Guardians can enter a classroom name when creating a student join code.
- The dashboard groups linked students by classroom and lets the guardian view each student separately.
